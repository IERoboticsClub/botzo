These are all the parts you need.

Note 1:	There are _meshmixer named parts of the main leg pieces that include meshmixer generated supports.   
	These are the file versions I printed, as the meshmixer supports were helpful. 

Note 2:	Also included are _experimental versions of the wrist pieces. They are modified versions to slightly
	widen the ground track of the robot's legs. I have not tried using these, but hopefully they may
	improve the robot's balance, which in the existing design could be improved. Try if you want, I 
	expect they will improve the balance.

Quantities:
battery_holder		x1
body_base		x1
body_lid		x1
foot_grip		x4
leg_knee		x4
nose			x1
sevo_alignment_tool	x1
shoulder_cover		x4
shoulder_pin		x4
thigh_righthand		x2
thigh_lefthand		x2
wrist_righthand		x2
wrist_lefthand		x2